#include "types.h"
#include "stat.h"
#include "user.h"

//This program prints all of a given text file to the console when cat.c is called
char buf[512];

//Void function takes in file descripter as arg
void
cat(int fd)
{
  //Declare variable to be used for number of bytes read
  int n;

  /*
    Uses read() to count up to number of bytes in the buffer from file descriptor fd into the 
    buffer starting at buf. Number of bytes read 'n' is returned. While 'n' is greater than zero, 
    continues while loop.
  */

  while((n = read(fd, buf, sizeof(buf))) > 0) {

    /*
      Uses write() to write the data out of the buffer 'buf', where 1 is the file descriptor and n is the number 
      of bytes in the buffer found earlier, if the return from the write() call equals to 'n'. If it does not
      equal to n, an error is printed to the terminal and then terminates the calling process.  
    */

    if (write(1, buf, n) != n) {
      printf(1, "cat: write error\n");
      exit();
    }
  }

  //If 'n' is less than 0 an error is printed to the terminal and then terminates the calling process.
  if(n < 0){
    printf(1, "cat: read error\n");
    exit();
  }
}

int
main(int argc, char *argv[])
{
  int fd, i;

  if(argc <= 1){
    cat(0);
    exit();
  }

  for(i = 1; i < argc; i++){
    if((fd = open(argv[i], 0)) < 0){
      printf(1, "cat: cannot open %s\n", argv[i]);
      exit();
    }
    cat(fd);
    close(fd);
  }
  exit();
}
