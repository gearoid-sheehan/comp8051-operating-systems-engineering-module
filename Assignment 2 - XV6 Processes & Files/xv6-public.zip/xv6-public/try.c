#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{

  //Call trace from operating system, turns it on. Will output to console
  trace(1);

  int fd = open("README", 0);
  close(fd);
  printf(1, "Hello");

  //Turn Tracing off, so system call tracing won't call on exit function
  trace(0);
  
  //System call won't be printed for the below call, as tracing is turned off
  int fd1 = open("README", 0);
  close(fd1);

  //Exit Program
  exit();
}
