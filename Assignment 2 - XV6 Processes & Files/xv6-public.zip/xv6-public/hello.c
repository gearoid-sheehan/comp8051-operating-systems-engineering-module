#include "types.h"
#include "stat.h"
#include "user.h"

/*
No standard C library in xv6 - Do not try to include as will not work and
may cause unprecedented behaviour
*/

int main(void)
{
  //Prints to terminal
  printf(1, "Hello world\n");
  exit();
}
