#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

//This program prints all of a given text file to the console when cat.c is called
char buf[512];

//Void function takes in file descripter as arg
void
cp (int fd0, int fd1)
{
  //Declare variable to be used for number of bytes read
  int n;

  /*
    Uses read() to count up to number of bytes in the buffer from file descriptor fd into the 
    buffer starting at buf. Number of bytes read 'n' is returned. While 'n' is greater than zero, 
    continues while loop.
  */

  while((n = read(fd0, buf, sizeof(buf))) > 0) {

    /*
      Uses write() to write the data out of the buffer 'buf', where 1 is the file descriptor and n is the number 
      of bytes in the buffer found earlier, if the return from the write() call equals to 'n'. If it does not
      equal to n, an error is printed to the terminal and then terminates the calling process.  
    */

    if (write(fd1, buf, n) != n) {
      printf(1, "cat: write error\n");
      exit();
    }
  }

  //If 'n' is less than 0 an error is printed to the terminal and then terminates the calling process.
  if(n < 0){
    printf(1, "cat: read error\n");
    exit();
  }

  //Close the file descriptors
  close(fd0);
  close(fd1);
  exit();
}

int
main(int argc, char *argv[])
{
    int fd0, fd1;

    if(argc <= 2){
        printf(1, "2 args required");
        exit();
    }

    //Open file for reading from
    fd0 = open(argv[1], 0);

    //Create and open file for writing to - if already exists destroy and recreate
    fd1 = open(argv[2], 0x202);

    //Call the cp function
    cp(fd0, fd1);

    exit();
}