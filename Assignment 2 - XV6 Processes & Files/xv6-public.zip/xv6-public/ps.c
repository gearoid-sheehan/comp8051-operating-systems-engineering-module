// ps.c
#include "types.h"
#include "stat.h"
#include "user.h"

//From proc.h Proc structure
//Per-process state

enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

struct uproc {
    int pid;
    int ppid;
    int state;
    uint sz;
    char name[16];
};

#define MAX_PROC 10
extern int getprocs(int,struct uproc[10]);

int main
(int argc, char *argv[]) {

    struct uproc ptable[MAX_PROC];
    struct uproc *p;
    int err;

    err = getprocs(10, ptable);

    printf(1, "Running Size: %d\n", err);

    if(err != 0) {
        printf(1,"Error getting ptable\n");
    }

    /* TODO output the process details */

    printf(1, "PID PPID STATE CMD\n");

    for (int i =0; i < err; i++) {
        
        printf(1, "%d %d %d %s\n", ptable[i].pid, p[i].ppid, ptable[i].state, ptable[i].name);
    }

    exit();
}