#include "types.h"
#include "stat.h"
#include "user.h"

//The wc file prints out 4 args - the number of lines, words and characters in a given file as well as the filename
char buf[512];

//Void function takes file descriptor 'fd' and the filename as arguments
void
wc(int fd, char *name)
{
  //Declare variables for loop and number of bytes read
  int i, n;

  //Declare variables for number of lines, words and characters as well as inword for boolean use
  int l, w, c, inword;

  /*
    Initialize number of lines, words and characters to 0.
    Initialize inword to 0 (false)
  */

  l = w = c = 0;
  inword = 0;

  /*
    Uses read() to count up to number of bytes in the buffer from file descriptor fd into the 
    buffer starting at buf. Number of bytes read 'n' is returned. While 'n' is greater than zero, 
    continues while loop. Looping over size of 'n' in for loop, increments the characters count for each iteration.
  */

  while((n = read(fd, buf, sizeof(buf))) > 0){
    for(i=0; i<n; i++){
      c++;

      //If the '\n' character appears, a new line has occured and the line count is incremented
      if(buf[i] == '\n')
        l++;
      
      //If the first occurance of a character in the given buffer is equal to one of " \r\t\n\v" it is not a new word so inword is 0 (false)
      if(strchr(" \r\t\n\v", buf[i]))
        inword = 0;
      
      //Else it is a new word and increment the word count "w" and inword is 1 (true)
      else if(!inword){
        w++;
        inword = 1;
      }
    }
  }

  //If the number of bytes read 'n' is less than zero print error msg to terminal and then terminates the calling process
  if(n < 0){
    printf(1, "wc: read error\n");
    exit();
  }

  //Finally, print the number of lines, words and characters found to the terminal, along with the name of the file
  printf(1, "%d %d %d %s\n", l, w, c, name);
}


int
main(int argc, char *argv[])
{
  //Declare variables for filedescriptor and loop
  int fd, i;

  //If there is only one or less argument entered, enter this loop
  if(argc <= 1){
    wc(0, "");
    //Terminates the calling process
    exit();
  }

  //Can input multiple files, this part loops over the files input, i.e "$ wc file1 file2 file3"
  for(i = 1; i < argc; i++){

    //If the file is less than zero, prints error to console then terminates the calling process
    if((fd = open(argv[i], 0)) < 0){
      printf(1, "wc: cannot open %s\n", argv[i]);
      exit();
    }

    //Calls the function which counts the lines, words and characters then closes fd
    wc(fd, argv[i]);
    close(fd);
  }

  //Terminates the calling process
  exit();
}

